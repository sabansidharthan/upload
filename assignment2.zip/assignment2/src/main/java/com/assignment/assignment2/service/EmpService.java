package com.assignment.assignment2.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.assignment.assignment2.model.Employee;
import com.assignment.assignment2.repository.DepartmentRepo;
import com.assignment.assignment2.repository.EmployeeRepo;

public class EmpService {
	@Autowired
	EmployeeRepo empRepo;
	@Autowired
	DepartmentRepo deptRepo;

	public String addEmployee(Employee emp) {
		if (empRepo.existsById(emp.getId())) {
			return "Employee already exist";	
		}
		else {		
			empRepo.save(emp);
			return "Employee data saved";
		}
	}
	public List<Employee> addEmpList(List<Employee> empList) {
		
		return empRepo.saveAll(empList);
		
	}
	
	public Boolean deleteEmployeeById(int id) {
		if (empRepo.existsById(id)) {
			empRepo.deleteById(id);
			return true;	
		}
		else {			
			return false;
		}
		
	}
	public List<Employee> getAllEmployee(){
		return empRepo.findAll();
		
	}
	
	public Optional<Employee> getEmployeeById(int id) {

			return empRepo.findById(id);	
	}
	
	public Optional<Employee> updateEmp(int id,Employee emp) {
		if (empRepo.existsById(id)) {
			emp.setId(id);
			empRepo.save(emp);
			return empRepo.findById(id);
		}
		else return null;
	}
	
	
	
	
}